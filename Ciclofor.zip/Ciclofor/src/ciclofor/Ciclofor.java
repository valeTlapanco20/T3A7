
package ciclofor;

import java.util.Scanner;


public class Ciclofor {

   
    public static void main(String[] args) {
       //ciclo(); 
       ejercicio1();
       //ejercicio2();
       //ejercicio3 ();
       //ejercicio4 ()
    }
    
    public static void ciclo (){
    //CREAR LISTA DE NUEMEROS DEL 1 AL 10CON EL CICLO FOR
    
    Scanner scanner = new Scanner(System.in);
    
    System.out.println("Ingresa el nùmero inicio");
        int nI = scanner.nextInt();
        
    System.out.println("Ingresa el numero Limite");
        int nL = scanner.nextInt();
    
    System.out.println("Ingresa ell nùmero Incremento");
        int nF = scanner.nextInt();
        
    if (nI < nL){
        for(int i = nI; i <= nL; i= i += nF){
        System.out.println("Numero actual es: " + i);
         }
    }   
        else if (nL < nI) {
            for(int i = nI; i >= nL; i= i -= nF){
        System.out.println("Numero actual es: " + i);
                }
    
        } else {
                System.out.println("El inicio es identico al limite " + nI + " = "+nL);    
                    }        
        
      }
    
    
    
    //EJERCICIO 1
    
    public static void ejercicio1(){
        Scanner scanner = new Scanner (System.in);
        
    System.out.println("Cuantos numetos quieres sumar:");
        int nI = scanner.nextInt();
        
    System.out.println("Desde que numero quieres iniciar:");
        int nL = scanner.nextInt();
    
    System.out.println("Incremento");
        int nF = scanner.nextInt();
        
    int numsuma = nI + nL;
        System.out.println("Inicio:" + nI
            + "\nLimite:" + numsuma
            + "\nCantidad de numeros a sumar:" +nL);
                
            int suma = 0;
            for (int i = nI; i <= numsuma; i += nF){
                suma = suma + i;
                System.out.println("Suma de los dos número: " + suma);
            }
    
    }
    
    
    //EJERCICIO 2
    
   public static void ejercicio2() {

        long producto = 1;
        for(int i = 1; i < 20; i+=2){
            producto = producto * i;
        }
        System.out.println("El producto de los 10 primeros numeros es: " + producto);
    }
    
   
   
   //EJERCICIO 3
   
    public static void ejercicio3() {
      String[] trabajadores = new String[3];
      int salario[]= new int[3];
      int i, pago, suma = 0, resul = 0;
      
      String trabajador, nombre;
      Scanner entrada = new Scanner(System.in);
        System.out.println("Ingresa el nombre de " + trabajadores.length + " trabajadores con su salario");
      for(i = 0; i <= trabajadores.length-1; i++){
          System.out.print("Ingresa el nombre del trabajador numero " + i + ": ");
          trabajadores[i] = entrada.next();
          System.out.println(trabajadores[i]);
          System.out.print("Ingresa el salario del trabajador numero " + i + ": $");
          salario[i] = entrada.nextInt();
      }
      for(i = 0; i <= trabajadores.length-1; i++){
          System.out.println("Los trajadores son: " + trabajadores[i]);
          suma = suma + salario[i];
      }
        resul = suma / salario.length;
        System.out.println("Su promedio de pago es de: $" + resul + " dolares");
    }
   
   //EJERCICIO 4
    
   public static void ejercicio4 (){
       Scanner scanner = new Scanner (System.in);
   int edad;
   int mayorDe18 = 0;
   int mayorDe175 = 0;
   float estatura, sumaEstatura;
   double promedioEstatura;
   
   for (int i = 0; i < 5; i ++){
       System.out.println("Edad");
       edad = scanner.nextInt();
       
       if (edad > 18){
           mayorDe18++;
       }
       
       System.out.println("Estatura");
       estatura = scanner.nextFloat();
       
       if (estatura > 1.75){
           mayorDe175++;
       }
       
       estatura += estatura;
       
       
               
   }
       System.out.println("Mayor de 18 años:" + mayorDe18);
       System.out.println("Mayor de 1.75:" + mayorDe175);
   }
   
   
   
}
    
    
    
   
    

